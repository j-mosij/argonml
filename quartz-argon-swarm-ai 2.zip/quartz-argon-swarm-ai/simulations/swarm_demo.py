#!/usr/bin/env python3
"""
Interactive demonstration of the Argon-Trapped Quartz Marble Swarm.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.swarm import Swarm
import time


def print_status(s: dict):
    bar_health = "█" * int(s["avg_health"] * 20) + "░" * (20 - int(s["avg_health"] * 20))
    bar_ion = "█" * int(s["avg_ionization"] * 20) + "░" * (20 - int(s["avg_ionization"] * 20))
    print(f"\n── Tick {s['tick']:4d} ──────────────────────────────────")
    print(f"  Nodes alive : {s['alive']:3d} / {s['n_nodes']}")
    print(f"  Avg Health  : [{bar_health}] {s['avg_health']:.3f}")
    print(f"  Avg Ioniz.  : [{bar_ion}] {s['avg_ionization']:.3f}")
    print(f"  Optical sig : {s['optical_signal']:.4f}")


def main():
    print("=" * 50)
    print("  Argon-Trapped Quartz Marble Swarm AI")
    print("  Speculative Cyber-Physical Simulation")
    print("=" * 50)
    print("\nInitializing 60-node swarm in 10×10×10 space...")

    swarm = Swarm(n_nodes=60, space_size=10.0)

    print("Running 40 ticks of stigmergic + self-healing dynamics...\n")

    for i in range(40):
        swarm.step()
        if i % 5 == 0 or i == 39:
            print_status(swarm.status())
        time.sleep(0.05)

    print("\n" + "=" * 50)
    print("Simulation complete.")
    print("The swarm has demonstrated:")
    print("  • Stigmergic communication via local fields")
    print("  • Cohesive movement toward neighbors")
    print("  • Self-healing of degraded nodes")
    print("  • Distributed optical signal propagation")
    print("=" * 50)


if __name__ == "__main__":
    main()
